function SignIn {
    <#
        .DESCRIPTION
            Signing in to Azure CLI using service principle via Connect-AzAccount
    #>
        param (
            # Parameter help description
            [Parameter(Mandatory=$True)]
            [string]
            $ApplicationId,
            [Parameter(Mandatory = $True)]
            [securestring]
            $Secret,
            [Parameter(Mandatory = $True)]
            [string]
            $tenantId
            )
        process
        {
            $pscredential = New-Object -TypeName System.Management.Automation.PSCredential($ApplicationId, $Secret)
            Connect-AzAccount -Credential $pscredential -Tenant $tenantId -ServicePrincipal -Verbose:$false -WarningAction Ignore | out-null
        }
    }
    Try
        {
            Write-Host "Checking required modules are installed... `n"

            Set-PSRepository PSGallery -InstallationPolicy Trusted
            $requiredModules = @("Az", "Az.Accounts", "Az.Resources","Az.ResourceGraph", "Az.RecoveryServices", "Az.Security", "ImportExcel")
            $installedModules = Get-InstalledModule

            foreach ($module in $requiredModules) {
                if (!($installedModules | Where-Object { $_.Name -eq $module })) {
                    Write-Output "Installing $module module"
                    Install-Module $module -AllowClobber -Force -confirm:$false
                    Import-Module -name $module -Force
                }
            }
        }
    Catch
        {
            Write-Error "Unable to install $module module"
            Write-Error "`n EXCEPTION: $_.Exception.message `r`n"
        }

    Try
        {
            Write-Host "Please sign-in to Azure `n"

            $secret = $Global:secret
            $ApplicationId = $Global:ApplicationId
            $tenantId = $Global:tenantId

            $secretstring = convertto-securestring $secret -asplaintext -force
            #SignIn -Applicationid $ApplicationId -Secret $secretstring -tenantId $tenantId

            Connect-AzAccount -Verbose:$false -WarningAction Ignore | out-null
        }
    Catch
        {
            Write-Error "Unable to connect to Azure"
            Write-Error "`n EXCEPTION: $_.Exception.message `r`n"
        }
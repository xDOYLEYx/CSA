$customercode = $Global:CustomerName
$output = $Global:oFile
$NewTagKey = $Global:NewTagKey
$SubSearch = $Global:SubSearch
$DryRun = $Global:DryRun
$Subscriptions = $Global:Subscriptions
$WarningPreference = "SilentlyContinue"
$FormatEnumerationLimit = -1

Write-Host " Generating Cloud Readiness Report.....please be patient" -ForegroundColor Green

Foreach($subscription in $Subscriptions){

        [void](Set-AzContext -SubscriptionId $subscription)
        $sub = Get-AzContext
####################################################################################
Try{
        ### Generating Secure Score
        $SecureScoreReport = [System.Collections.ArrayList]::new()

        $GetSecureScore = Get-AzSecuritySecureScore
        $cur = $GetSecureScore.CurrentScore
        $max = $GetSecureScore.MaxScore
        $SecureScore = ($cur/$max).ToString("P")

        $sub = Get-AzContext

        [void]$SecureScoreReport.Add([PSCustomObject]@{
                SubscriptionName = $sub.Subscription.Name
                SecureScore = $SecureScore
            })
        $SecureScoreReport | Export-Excel -workSheetName "Secure Score" -path $output -AutoSize -AutoFilter -Append
}
catch
{
    Write-Host "Failed to generate Secure Score"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
}
####################################################################################
Try{
        ### Azure Backups

        $vms = Get-AzVM -status
        $backupVaults = Get-AzRecoveryServicesVault
        $sub1 = Get-AzContext

        $vmBackupReport = [System.Collections.ArrayList]::new()
        foreach ($vm in $vms)
        {
            $VmPowerState1 = Get-AzVM -ResourceGroupName $vm.ResourceGroupName -Status | Select Name, PowerState
            $VmPowerState = $VmPowerState1.PowerState | Where-Object {$VmPowerState1.Name -eq $vm.Name}

            $recoveryVaultInfo = Get-AzRecoveryServicesBackupStatus -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Type 'AzureVM'
            if ($recoveryVaultInfo.BackedUp -eq $true)
            {
                #Write-Host "$($vm.Name) - BackedUp : Yes"
                #Backup Recovery Vault Information
                $vmBackupVault = $backupVaults | Where-Object {$_.ID -eq $recoveryVaultInfo.VaultId}

                #Backup recovery Vault policy Information
                $container = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -VaultId $vmBackupVault.ID -FriendlyName $vm.Name #-Status "Registered"
                $backupItem = Get-AzRecoveryServicesBackupItem -Container $container -WorkloadType AzureVM -VaultId $vmBackupVault.ID
            } #if ($recoveryVaultInfo.BackedUp -eq $true)
            else
            {
                #Write-Host "$($vm.Name) - BackedUp : No" -BackgroundColor DarkRed
                $vmBackupVault = $null
                $container =  $null
                $backupItem =  $null
            } #else if ($recoveryVaultInfo.BackedUp -eq $true)

            [void]$vmBackupReport.Add([PSCustomObject]@{
                Subscription_Name = $sub1.Subscription.Name
                VM_Name = $vm.Name
                #VM_Status = $VmPowerState
                VM_Location = $vm.Location
                VM_ResourceGroupName = $vm.ResourceGroupName
                VM_BackedUp = $recoveryVaultInfo.BackedUp
                VM_RecoveryVaultName =  $vmBackupVault.Name
                VM_RecoveryVaultPolicy = $backupItem.ProtectionPolicyName
                VM_BackupHealthStatus = $backupItem.HealthStatus
                VM_BackupProtectionStatus = $backupItem.ProtectionStatus
                VM_LastBackupStatus = $backupItem.LastBackupStatus
                VM_LastBackupTime = $backupItem.LastBackupTime
                VM_BackupDeleteState = $backupItem.DeleteState
                VM_BackupLatestRecoveryPoint = $backupItem.LatestRecoveryPoint
                VM_Id = $vm.Id
                RecoveryVault_ResourceGroupName = $vmBackupVault.ResourceGroupName
                RecoveryVault_Location = $vmBackupVault.Location
                RecoveryVault_SubscriptionId = $vmBackupVault.ID
            }) #[void]$vmBackupReport.Add([PSCustomObject]@{
        }
        $vmBackupReport | Export-Excel -workSheetName "Backup Report" -path $output -AutoSize -AutoFilter -Append
        #Process

        #{
         #   $vmBackupReport | Export-Excel -workSheetName "BackupReport" -path $output
        #} #end
}
catch
{
    Write-Host "Failed to generate Azure Backups"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    return
}

####################################################################################
Try
{
        ### Azure Security Recommendations

        $currentSubscription = Get-AzContext

        $RecommendationTable = @()
        $SecurityTasks = Search-AzGraph -Query "SecurityResources | where type == 'microsoft.security/assessments' | extend resourceId=id, recommendationId=name, recommendationName=properties.displayName, source=properties.resourceDetails.Source, recommendationState=properties.status.code, description=properties.metadata.description, assessmentType=properties.metadata.assessmentType, remediationDescription=properties.metadata.remediationDescription, policyDefinitionId=properties.metadata.policyDefinitionId, implementationEffort=properties.metadata.implementationEffort, recommendationSeverity=properties.metadata.severity, category=properties.metadata.categories, userImpact=properties.metadata.userImpact, threats=properties.metadata.threats, portalLink=properties.links.azurePortal | project tenantId, subscriptionId, resourceId, recommendationName, recommendationId, recommendationState, recommendationSeverity, description, remediationDescription, assessmentType, policyDefinitionId, implementationEffort, userImpact, category, threats, source, portalLink" -Subscription $currentSubscription.Subscription.Id

        foreach($SecurityTask in $SecurityTasks)
                {
                    $Recommendations = New-Object psobject -Property @{
                        SubscriptionName = $sub1.Subscription.Name
                        Recommendation = $SecurityTask.recommendationName
                        Severity = $SecurityTask.recommendationSeverity
                        Resource = ($SecurityTask.ResourceId.Split("/")[8])
                        Remediation = $SecurityTask.remediationDescription
                        SubscriptionId = ($SecurityTask.ResourceId.Split("/")[2])
                        ResourceGroup = ($SecurityTask.ResourceId.Split("/")[4])
                        }
                    $RecommendationTable += $Recommendations
                }

        $RecommendationTable | Select-Object "SubscriptionName", "SubscriptionId", "Resource", "ResourceGroup", "Recommendation", "Severity" | Export-Excel -workSheetName "Security Recommendations" -path $output -AutoSize -AutoFilter -Append

}
catch
{
    Write-Host "Failed to generate Security Recommendations"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    return
}

####################################################################################
Try{
        ### Azure Update Report
        $UpdateReport = [System.Collections.ArrayList]::new()
        $sub = Get-AzContext

        $VirtM = Get-AzVM -status
        ForEach($VirtMs in $VirtM)
        {
            $Config = $VirtMs.OSProfile.WindowsConfiguration
            $MMAgent = $VirtMs.Extensions | Where-Object {$_.Name -eq "MicrosoftMonitoringAgent"}
            $PowerState1 = Get-AzVM -ResourceGroupName $VirtMs.ResourceGroupName -Status
            $PowerState = $PowerState1.PowerState | Where-Object {$PowerState1.Name -eq $VirtM.Name}

            #$Workspace = $MMAgent.Settings | Where-Object {$_.HasValues -eq $true}

            [void]$UpdateReport.Add([PSCustomObject]@{
                    SubscriptionName = $sub.Subscription.Name
                    VM_ResourceGroupName = $VirtMs.ResourceGroupName
                    VM_Name = $VirtMs.Name
                    #VM_Status = $PowerState
                    VM_Location = $VirtMs.Location
                    Provision_VM_Agent = $Config.ProvisionVMAgent
                    Enable_Automatic_Updates = $Config.EnableAutomaticUpdates
                    Patch_Mode = $Config.PatchSettings.PatchMode
                    })
        }

        $UpdateReport | Export-Excel -workSheetName "Update Report" -path $output -AutoSize -AutoFilter -Append

}
catch
{
    Write-Host "Failed to generate Update Report"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    return
}
####################################################################################
Try{
        ### Azure Policy Report
        $PolicyReport = [System.Collections.ArrayList]::new()
        $Pol = Get-AzPolicyAssignment

        ForEach($Item in $Pol)
        {
            $Properties = $Item.Properties

            [void]$PolicyReport.Add([PSCustomObject]@{
                    SubscriptionName = $sub.Subscription.Name
                    SubscriptionId = $sub.Subscription.Id
                    Policy_Name = $Properties.DisplayName
                    Scope = $Properties.Scope
                    Description = $Properties.Description
                    Metadata = $Properties.Metadata
                    EnforcementMode = $Properties.EnforcementMode
                    PolicyDefinitionId = $Properties.PolicyDefinitionId
                    Parameters = $Properties.Parameters
                    })
        }


        $PolicyReport | Export-Excel -workSheetName "Azure Policy" -path $output -AutoSize -AutoFilter -Append

}
catch
{
    Write-Host "Failed to generate Policy Report"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    return
}
####################################################################################
Try{
        ### Generating Policy Score
        $PolicyScoreReport = [System.Collections.ArrayList]::new()
        $CurSub = Get-AzContext

        $Query = "policyresources | where tolower(properties.policyAssignmentName) != 'securitycenterbuiltIn'
        | extend complianceState=tostring(properties['complianceState']), resourceId=tostring(properties['resourceId'])
        | project subscriptionId, complianceState, resourceId
        | summarize complianceStates=make_list(complianceState) by subscriptionId, resourceId
        | summarize Total = count()
          , Compliant = countif((complianceStates notcontains 'NonCompliant') and (complianceStates contains 'Compliant'))
          , Exempt = countif((complianceStates notcontains 'NonCompliant') and (complianceStates notcontains 'Compliant') and (complianceStates contains 'Exempt'))
          , NonCompliant = countif (complianceStates contains 'NonCompliant') by subscriptionId
        | extend OverallCompliancePerc = round(toreal(Compliant + Exempt) / toreal(Total), 2)
        | extend SubscriptionName = ''
        | project SubscriptionName, subscriptionId, Total, Compliant, Exempt, NonCompliant, OverallCompliancePerc
        | order by OverallCompliancePerc desc
        "
        $Results = Search-AzGraph -Query $Query -Subscription $sub.Subscription.Id
        #$PolCompScore = ($Results.OverallCompliancePerc).ToString("P")
        $PolCompScore = $Results | Where-Object {$_.subscriptionId -eq $CurSub.Subscription.Id}
        $PolCompScore1 = ($PolCompScore.OverallCompliancePerc).ToString("P")

        #$sub = Get-AzContext

        [void]$PolicyScoreReport.Add([PSCustomObject]@{
                SubscriptionName = $CurSub.Subscription.Name
                Total = $Results.Total
                Compliant = $Results.Compliant
                Exempt = $Results.Exempt
                NonCompliant = $Results.NonCompliant
                CompliantPercentage = $PolCompScore1
            })
        $PolicyScoreReport | Export-Excel -workSheetName "Policy Compliant Score" -path $output -AutoSize -AutoFilter -Append
}
catch
{
    Write-Host "Failed to generate Policy Score"
    Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    return
}}
####################################################################################
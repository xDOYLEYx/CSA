#Requires -RunAsAdministrator
#Requires -Version 7.0
#########################################
### Vaiables ###
#########################################
## Main variables ##
$Global:CustomerName = Read-Host "Please enter name for report: `n"
## Service account details ##

$Global:secret = 'xxx'
$Global:ApplicationId = "xxxx"
$Global:tenantId = "xxxx"

#########################################
#########################################
## Output file ##
$date = Get-Date -UFormat("%d-%m-%y")
$currentDir = $(Get-Location).Path
$Global:oFile = "$($currentDir)\Output\$($Global:CustomerName)_CSA_$($date).xlsx"
## Filter search - Wildcard for all subscriptions ##
#########################################
### Signing in to Azure CLI - Using LAU-Automation-App ###
Try
    {
        $AzureSignInScript = '.\Azure_Signin.ps1'
        Invoke-Expression $AzureSignInScript
    }
catch
    {
        Write-Host "Unable to sign-in to Azure CLI"
        Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    }
#########################################
### Creating array for subscriptions ###
Try
    {
        $Global:Subscriptions = Get-AzSubscription | Where-object{($_.State -eq "Enabled")} | Sort-Object Name
    }
catch
    {
        Write-Host "Issue has occured with Get-AzSubscription"
        Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    }

Try
    {
        $AzureCSAScript = '.\Azure_CSA.ps1'
        Invoke-Expression $AzureCSAScript
    }
catch
    {
        Write-Host "Unable to sign-in to Azure CLI"
        Write-host "`n EXCEPTION: $_.Exception.message `r`n"
    }
### Clean up variabels and sign-out of Azure CLI ###
Disconnect-AzAccount | out-null
Clear-AzContext -force | out-null
$Global:Subscriptions = ""
$Global:CustomerName = ""
$Global:NewTagKey = ""
$Global:secret = ''
$Global:ApplicationId = ""
$Global:tenantId = ""
$Global:oFile = ""
$Global:SubSearch = ""
$Global:DryRun = ""
#########################################
Write-Output "Completed"